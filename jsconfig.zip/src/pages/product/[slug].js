import { useRouter } from "next/router";
import { useState, useEffect } from "react";

const ProductDetail = () => {
  const router = useRouter();
  const { slug } = router.query;
  const [product, setProduct] = useState(null);

  const fetchProduct = (slug) => {
    // Simulate fetching product data (you can replace this with a real API call)
    const products = [
      {
        slug: "pure-uppada-partly-silk",
        name: "Pure Uppada Partly Silk",
        description: "Pure Uppada partly silk saree pink and navy blue with plain body and zari.",
        price: 1999,
        image: "/assets/images/t-1.jpg",
      },
      {
        slug: "another-product",
        name: "Another Product",
        description: "Description for another product.",
        price: 999,
        image: "/assets/images/t-2.jpg",
      },
      // more products here...
    ];

    const foundProduct = products.find((prod) => prod.slug === slug);
    setProduct(foundProduct);
  };

  useEffect(() => {
    if (slug) {
      fetchProduct(slug);
    }
  }, [slug]);

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <section className="product-detail">
      <div className="container">
        <div className="row g-5">
          <div className="col-lg-6">
            <img src={product.image} alt={product.name} className="img-fluid" />
          </div>
          <div className="col-lg-6">
            <h1>{product.name}</h1>
            <p>{product.description}</p>
            <p>
              <strong>Price: ₹{product.price}</strong>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductDetail;
