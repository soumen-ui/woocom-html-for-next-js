// pages/_app.js
import 'bootstrap/dist/css/bootstrap.min.css';
import 'slick-carousel/slick/slick.css'; 
import 'slick-carousel/slick/slick-theme.css';

import "@/styles/globals.css";
import { useEffect } from "react";

export default function App({ Component, pageProps }) {
  useEffect(() => {
    // Only runs on client side after the first render
    import('bootstrap/dist/js/bootstrap.bundle.min.js');
    // import('/assets/css2/owl.carousel.min.css');
    // import('/assets/css2/style.css');
  }, []);

  

  useEffect(() => {
      const loadScript = (src) => {
        const script = document.createElement('script');
        script.src = src;
        script.async = false;
        document.body.appendChild(script);
      };
  
      // loadScript('https://code.jquery.com/jquery-3.6.0.min.js');
      // loadScript('/engine1/script.js');
      loadScript('/assets/js2/jquery.min.js');
      loadScript('/assets/js2/owl.carousel.min.js');
      loadScript('/assets/js2/customize.js');


    }, []);

   return (
    <>
      <link rel="stylesheet" href="/assets/css2/owl.carousel.min.css" />
    <link rel="stylesheet" type="text/css" href="/assets/css2/style.css"></link>

  <Component {...pageProps} />
</>
);
}
