import ProductList from "./components/ProductList";

const Trends = () => {
  return (
    <div>
      <h1>Trending Products</h1>
      <ProductList />
    </div>
  );
};

export default Trends;
