import { useState } from "react";
import Link from 'next/link';

const ProductList = () => {
    const [filters, setFilters] = useState({
        latest: false,
        bestSelling: true,
        mostViewed: false,
        lowToHigh: false,
        highToLow: true,
    });

    const handleFilterChange = (filterName) => {
        setFilters({
            ...filters,
            [filterName]: !filters[filterName],
        });
    };

    const products = [
        {
            slug: 'pure-uppada-partly-silk', 
            name: 'Pure Uppada Partly Silk',
            description: 'Pure Uppada partly silk saree pink and navy blue with plain body and zari.',
            price: 1999,
            image: '/assets/images/t-1.jpg',
        },
        {
            slug: 'another-product',
            name: 'Another Product',
            description: 'Description for another product.',
            price: 999,
            image: '/assets/images/t-2.jpg',
        },
        // Add more products as needed
    ];

    return (
        <section className="fluid-block collections">
            <div className="container">
                <div className="row g-5">
                    <div className="col-lg-3">
                        {/* Filters Section */}
                        {/* Your filter code remains unchanged */}
                    </div>
                    <div className="col-lg-9">
                        <div className="title-div d-flex align-items-center justify-content-between">
                            <div className="left">
                                <h2 className="fw-bold mb-0 text-uppercase fs-3">Product List</h2>
                            </div>
                            {/* Sort options */}
                        </div>

                        <div className="row g-5">
          {products.map((product) => (
            <div key={product.slug} className="col-lg-4">
              <div className="card border-0 rounded-0">
                <Link href={`/product/${product.slug}`} passHref>
                  <div className="card-img position-relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="img-fluid"
                    />
                  </div>
                </Link>
                <div className="card-body p-4 shadow-lg">
                  <div className="info">
                    <h4 className="fw-bold fs-5 pb-2">{product.name}</h4>
                    <p>{product.description}</p>
                  </div>
                  <div className="price d-flex align-items-center">
                    <div className="left">
                      <strong className="fs-4">₹{product.price}</strong>
                    </div>
                    <div className="right">
                      <span className="text-success">In Stock</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default ProductList;



// import { useState } from "react";
// import Link from 'next/link';

// const ProductList = () => {
//     const [filters, setFilters] = useState({
//         latest: false,
//         bestSelling: true,
//         mostViewed: false,
//         lowToHigh: false,
//         highToLow: true,
//     });

//     const handleFilterChange = (filterName) => {
//         setFilters({
//             ...filters,
//             [filterName]: !filters[filterName],
//         });
//     };

//     return (
//         <section className="fluid-block collections">
//             <div className="container">
//                 <div className="row g-5">
//                     <div className="col-lg-3">
//                         <div className="card filter">
//                             <div className="card-header d-flex align-items-center justify-content-between p-0 border-0 mb-3 border-radius-0">
//                                 <h4 className="card-title mb-0">
//                                     <i className="bi bi-funnel"></i> Filter
//                                 </h4>
//                                 <a href="#" className="btn btn-sm btn-outline-danger rounded-0">
//                                     Clear All
//                                 </a>
//                             </div>
//                             <div className="card-body">
//                                 {/* Short By Type */}
//                                 <div className="filter-item border-bottom py-3 pt-0">
//                                     <h4 className="card-title mb-3 border-bottom pb-3 d-flex align-items-center justify-content-between">
//                                         Short By Type <span className="badge rounded-pill bg-danger fs-sm">3</span>
//                                     </h4>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.latest}
//                                             onChange={() => handleFilterChange("latest")}
//                                         />
//                                         <label className="form-check-label">Latest</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.bestSelling}
//                                             onChange={() => handleFilterChange("bestSelling")}
//                                         />
//                                         <label className="form-check-label">Best Selling</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.mostViewed}
//                                             onChange={() => handleFilterChange("mostViewed")}
//                                         />
//                                         <label className="form-check-label">Most Viewed</label>
//                                     </div>
//                                 </div>

//                                 {/* Short By Brand */}
//                                 <div className="filter-item border-bottom py-3">
//                                     <h4 className="card-title mb-3 border-bottom pb-3 d-flex align-items-center justify-content-between">
//                                         Short By Brand <span className="badge rounded-pill bg-danger fs-sm">3</span>
//                                     </h4>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.latest}
//                                             onChange={() => handleFilterChange("latest")}
//                                         />
//                                         <label className="form-check-label">Latest</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.bestSelling}
//                                             onChange={() => handleFilterChange("bestSelling")}
//                                         />
//                                         <label className="form-check-label">Best Selling</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.mostViewed}
//                                             onChange={() => handleFilterChange("mostViewed")}
//                                         />
//                                         <label className="form-check-label">Most Viewed</label>
//                                     </div>
//                                 </div>

//                                 {/* Short By Color */}
//                                 <div className="filter-item border-bottom py-3">
//                                     <h4 className="card-title mb-3 border-bottom pb-3 d-flex align-items-center justify-content-between">
//                                         Short By Color <span className="badge rounded-pill bg-danger fs-sm">3</span>
//                                     </h4>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.latest}
//                                             onChange={() => handleFilterChange("latest")}
//                                         />
//                                         <label className="form-check-label">Latest</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.bestSelling}
//                                             onChange={() => handleFilterChange("bestSelling")}
//                                         />
//                                         <label className="form-check-label">Best Selling</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.mostViewed}
//                                             onChange={() => handleFilterChange("mostViewed")}
//                                         />
//                                         <label className="form-check-label">Most Viewed</label>
//                                     </div>
//                                 </div>

//                                 {/* Short By Price */}
//                                 <div className="filter-item border-bottom py-3">
//                                     <h4 className="card-title mb-3 border-bottom pb-3">Short By Price</h4>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.lowToHigh}
//                                             onChange={() => handleFilterChange("lowToHigh")}
//                                         />
//                                         <label className="form-check-label">Low to High</label>
//                                     </div>
//                                     <div className="form-check">
//                                         <input
//                                             className="form-check-input"
//                                             type="checkbox"
//                                             checked={filters.highToLow}
//                                             onChange={() => handleFilterChange("highToLow")}
//                                         />
//                                         <label className="form-check-label">High to Low</label>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                     </div>
//                     <div className="col-lg-9">
//                         <div className="title-div d-flex align-items-center justify-content-between">
//                             <div className="left">
//                                 <h2 className="fw-bold mb-0 text-uppercase fs-3">Pure uppada partly silk</h2>
//                             </div>
//                             <div className="right">
//                                 <div className="left d-flex justify-content-between align-items-center gap-1">
//                                     <label for="inputGroupSelect01" className="form-label w-50 mb-0">Sort By:</label>
//                                     <select className="form-select rounded-0" aria-label="Large select example">
//                                         <option selected="">New Arrivals</option>
//                                         <option value="1">Best Seller</option>
//                                         <option value="2">Recomendations</option>
//                                         <option value="3">Price: Low to High</option>
//                                         <option value="3">Price: High to Low</option>
//                                     </select>
//                                 </div>
//                             </div>
//                         </div>
                        

//                         <div className="row g-5">
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="product-details.html" className="card-img position-relative">
//                                         <div className="icons-bar">
//                                             <div className="icon active" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">
                                               
//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <div className="offer-badge bg-success">20% OFF</div>
//                                         <img src="/assets/images/t-1.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left d-flex align-items-center gap-2">
//                                                 <strong className="fs-4">₹1999</strong> <span className="fs-5 text-decoration-line-through text-muted">₹2499</span>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-success">In Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">
                                               
//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-2.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-success">In Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-3.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-success">In Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
                            
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-4.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-danger">Out Of Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-1.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-danger">Out Of Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-2.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-danger">Out Of Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-2.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-danger">Out Of Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-1.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-danger">Out Of Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col-lg-4">
//                                 <div className="card border-0 rounded-0">
//                                     <Link href="#" className="card-img">
//                                         <div className="icons-bar">
//                                             <div className="icon" title="Wishlist"><i className="bi bi-heart-fill"></i></div>
//                                             <div className="icon" title="Share">

//                                             </div>
//                                             <div className="icon" title="Add to Cart">

//                                             </div>
//                                         </div>
//                                         <img src="/assets/images/t-3.jpg" alt="" className="img-fluid" />
//                                     </Link>
//                                     <div className="card-body p-4 shadow-lg">
//                                         <div className="info">
//                                             <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
//                                             <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
//                                         </div>
//                                         <div className="price d-flex align-items-center">
//                                             <div className="left">
//                                                 <strong className="fs-4">₹1999</strong>
//                                             </div>
//                                             <div className="right">
//                                                 <span className="text-danger">Out Of Stock</span>
//                                             </div>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
                          
//                         </div>

//                     </div>

//                 </div>
//             </div>
//         </section>
//     );
// };

// export default ProductList;
