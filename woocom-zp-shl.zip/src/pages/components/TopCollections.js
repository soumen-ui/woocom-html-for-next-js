// components/TopCollections.js
import Image from 'next/image';
import Link from "next/link";
import 'swiper/css';

const TopCollections = () => {
    return (

        <>

            {/* Category start */}

            <section className="fluid-block category pb-0">
                <div className="container">
                    <div className="title-div text-center text-uppercase mb-5">
                        <h2 className="fw-bold">Shop By Category</h2>
                    </div>
                    <div className="row">
                        <div className="col-lg-2 col-sm-4 col-6">
                            <a href="product-listing.html" className="card text-center border-0">
                                <img src="images/k-1.jpg" className="card-img-top" alt="Vinayaka Jewellers" />
                                <div className="card-body py-4 px-2">
                                    <h5 className="card-title text-uppercase fw-bold">Necklaces</h5>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-2 col-sm-4 col-6">
                            <a href="product-listing.html" className="card text-center border-0">
                                <img src="images/k-2.jpg" className="card-img-top" alt="Vinayaka Jewellers" />
                                <div className="card-body py-4 px-2">
                                    <h5 className="card-title text-uppercase fw-bold">Earrings</h5>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-2 col-sm-4 col-6">
                            <a href="product-listing.html" className="card text-center border-0">
                                <img src="images/k-3.jpg" className="card-img-top" alt="Vinayaka Jewellers" />
                                <div className="card-body py-4 px-2">
                                    <h5 className="card-title text-uppercase fw-bold">Diamond Ring</h5>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-2 col-sm-4 col-6">
                            <a href="product-listing.html" className="card text-center border-0">
                                <img src="images/k-4.jpg" className="card-img-top" alt="Vinayaka Jewellers" />
                                <div className="card-body py-4 px-2">
                                    <h5 className="card-title text-uppercase fw-bold">Braclets</h5>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-2 col-sm-4 col-6">
                            <a href="product-listing.html" className="card text-center border-0">
                                <img src="images/k-1.jpg" className="card-img-top" alt="Vinayaka Jewellers" />
                                <div className="card-body py-4 px-2">
                                    <h5 className="card-title text-uppercase fw-bold">Chains</h5>
                                </div>
                            </a>
                        </div>
                        <div className="col-lg-2 col-sm-4 col-6">
                            <a href="#" className="card text-center border-0">
                                <img src="images/k-3.jpg" className="card-img-top" alt="Vinayaka Jewellers" />
                                <div className="card-body py-4 px-2">
                                    <h5 className="card-title text-uppercase fw-bold">Pendant</h5>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </section>

            {/* Category End */}

            {/* New Arrivals start */}
            <section className="fluid-block collections">
                <div className="container">
                    <div className="title-div d-flex align-items-center justify-content-between">
                        <div className="left">
                            <h2 className="text-uppercase fw-bold mb-0">New Arrivals</h2>
                            <ul className="d-flex align-items-center">
                                <li>Pure Silk</li>
                                <li><strong>25% Off collections</strong></li>
                            </ul>
                        </div>
                        <div className="right">
                            <a href="#" className="btn btn-outline-primary text-uppercase">View All</a>
                        </div>
                    </div>
                    <div className="row g-5">
                        {/* Product 1 */}
                        <div className="col-lg-3">
                            <div className="card border-0 rounded-0">
                                <a href="#" className="card-img">
                                    <Image src="/images/t-1.jpg" alt="Pure Uppada Partly Silk" className="img-fluid" width={500} height={500} />
                                </a>
                                <div className="card-body p-4 shadow-lg">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure Uppada Partly Silk</h4>
                                        <p>Pure Uppada partly silk saree pink and navy blue with plain body and zari.</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Product 2 */}
                        <div className="col-lg-3">
                            <div className="card border-0 rounded-0">
                                <a href="#" className="card-img">
                                    <Image src="/images/t-2.jpg" alt="Pure Uppada Partly Silk" className="img-fluid" width={500} height={500} />
                                </a>
                                <div className="card-body p-4 shadow-lg">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure Uppada Partly Silk</h4>
                                        <p>Pure Uppada partly silk saree pink and navy blue with plain body and zari.</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Product 3 */}
                        <div className="col-lg-3">
                            <div className="card border-0 rounded-0">
                                <a href="#" className="card-img">
                                    <Image src="/images/t-3.jpg" alt="Pure Uppada Partly Silk" className="img-fluid" width={500} height={500} />
                                </a>
                                <div className="card-body p-4 shadow-lg">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure Uppada Partly Silk</h4>
                                        <p>Pure Uppada partly silk saree pink and navy blue with plain body and zari.</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Product 4 */}
                        <div className="col-lg-3">
                            <div className="card border-0 rounded-0">
                                <a href="#" className="card-img">
                                    <Image src="/images/t-4.jpg" alt="Pure Uppada Partly Silk" className="img-fluid" width={500} height={500} />
                                </a>
                                <div className="card-body p-4 shadow-lg">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure Uppada Partly Silk</h4>
                                        <p>Pure Uppada partly silk saree pink and navy blue with plain body and zari.</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-danger">Out Of Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            {/* New Arrivals End */}



            <section className="fluid-block collections bg_secondary">
                <div className="container">
                    <div className="title-div d-flex align-items-center justify-content-between">
                        <div className="left">
                            <h2 className="text-uppercase fw-bold mb-0">Our top Collections</h2>
                            <ul className="d-flex align-items-center">
                                <li>Pure Silk</li>
                                <li><strong>25% Off collections</strong></li>
                            </ul>
                        </div>
                        <div className="right">
                            <Link href="#" className="btn btn-outline-primary text-uppercase">View All</Link>
                        </div>
                    </div>
                    <div className="owl-carousel" id="collections">
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/n-1.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/n-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/n-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/n-4.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/n-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/n-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default TopCollections;
