// components/TopCollections.js
import { Swiper, SwiperSlide } from 'swiper/react';
import Link from "next/link";
import 'swiper/css';

const FestivalCollections = () => {
    return (
        <>

            <section class="special-choice">
                <div class="container">
                    <img src="images/special_choice.jpg" class="img-fluid" alt="..." />
                </div>
            </section>


            <section className="fluid-block collections">
                <div className="container">
                    <div className="title-div d-flex align-items-center justify-content-between">
                        <div className="left">
                            <h2 className="text-uppercase fw-bold mb-0">Festival Collection</h2>
                            <ul className="d-flex align-items-center">
                                <li>Chiniya Silk</li>
                                <li><strong>15% Off collections</strong></li>
                            </ul>
                        </div>
                        <div className="right">
                            <Link href="#" className="btn btn-outline-primary text-uppercase">View All</Link>
                        </div>
                    </div>
                    <div className="owl-carousel" id="collections-2">
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/f-1.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4 border">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/f-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4 border">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/f-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4 border">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/f-4.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4 border">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/f-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4 border">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/f-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <div className="card-body p-4 border">
                                    <div className="info">
                                        <h4 className="fw-bold fs-5 pb-2">Pure uppada partly silk</h4>
                                        <p>Pure uppada partly silk saree pink and navy blue with plain body and zari</p>
                                    </div>
                                    <div className="price d-flex align-items-center">
                                        <div className="left">
                                            <strong className="fs-4">₹1999</strong>
                                        </div>
                                        <div className="right">
                                            <span className="text-success">In Stock</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="fluid-block offers">
                <div className="container col-lg-8 mx-auto">
                    <div className="title-div text-center text-uppercase mb-5 stroke-none">
                        <h2 className="fw-bold text-white">offers you get with every products</h2>
                    </div>
                    <div className="d-flex align-items-center justify-content-center text-center">
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path
                                    d="M3.51819 10.3058C3.13013 9.23176 2.9361 8.69476 3.01884 8.35065C3.10933 7.97427 3.377 7.68084 3.71913 7.58296C4.03193 7.49346 4.51853 7.70973 5.49173 8.14227C6.35253 8.52486 6.78293 8.71615 7.18732 8.70551C7.63257 8.69379 8.06088 8.51524 8.4016 8.19931C8.71105 7.91237 8.91861 7.45513 9.33373 6.54064L10.2486 4.52525C11.0128 2.84175 11.3949 2 12 2C12.6051 2 12.9872 2.84175 13.7514 4.52525L14.6663 6.54064C15.0814 7.45513 15.289 7.91237 15.5984 8.19931C15.9391 8.51524 16.3674 8.69379 16.8127 8.70551C17.2171 8.71615 17.6475 8.52486 18.5083 8.14227C19.4815 7.70973 19.9681 7.49346 20.2809 7.58296C20.623 7.68084 20.8907 7.97427 20.9812 8.35065C21.0639 8.69476 20.8699 9.23176 20.4818 10.3057L18.8138 14.9222C18.1002 16.897 17.7435 17.8844 16.9968 18.4422C16.2502 19 15.2854 19 13.3558 19H10.6442C8.71459 19 7.74977 19 7.00315 18.4422C6.25654 17.8844 5.89977 16.897 5.18622 14.9222L3.51819 10.3058Z"
                                    stroke="currentColor" stroke-width="0.7" />
                                <path d="M12 14H12.009" stroke="currentColor" stroke-width="0.7" stroke-linecap="round"
                                    stroke-linejoin="round" />
                                <path d="M7 22H17" stroke="currentColor" stroke-width="0.7" stroke-linecap="round" />
                            </svg>
                            <h5 className="card-title mt-3">BIS Hallmarked Pure Gold</h5>
                        </div>
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path
                                    d="M4 2V5.13219C4 5.42605 4.36724 5.55908 4.55527 5.33333C6.3854 3.2875 9.04499 2 12.0051 2C17.5251 2 22 6.47715 22 12C22 15.9582 19.7015 19.3793 16.367 21"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M11.7347 22.0001C12.2016 22.0001 12.6611 21.9688 13.1111 21.9084M2.26537 8.66675C2.15297 9.06394 2.06477 9.46536 2 9.86901M2.03457 13.5381C2.10487 13.9381 2.19644 14.3343 2.30852 14.7245M3.83292 17.9963C4.07124 18.3497 4.3296 18.69 4.6071 19.0147M7.42857 21.3607C7.78228 21.5632 8.15042 21.7464 8.53228 21.9084"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <h5 className="card-title mt-3">Guaranted Buyback</h5>
                        </div>
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path d="M11 13H16M8 13H8.00898M13 17H8M16 17H15.991" stroke="currentColor" stroke-width="0.7"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M18 2V4M6 2V4" stroke="currentColor" stroke-width="0.7" stroke-linecap="round"
                                    stroke-linejoin="round" />
                                <path
                                    d="M2.5 12.2432C2.5 7.88594 2.5 5.70728 3.75212 4.35364C5.00424 3 7.01949 3 11.05 3H12.95C16.9805 3 18.9958 3 20.2479 4.35364C21.5 5.70728 21.5 7.88594 21.5 12.2432V12.7568C21.5 17.1141 21.5 19.2927 20.2479 20.6464C18.9958 22 16.9805 22 12.95 22H11.05C7.01949 22 5.00424 22 3.75212 20.6464C2.5 19.2927 2.5 17.1141 2.5 12.7568V12.2432Z"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M3 8H21" stroke="currentColor" stroke-width="0.7" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <h5 className="card-title mt-3">7 Days Return Policy</h5>
                        </div>
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path
                                    d="M12 9C10.8954 9 10 9.67157 10 10.5C10 11.3284 10.8954 12 12 12C13.1046 12 14 12.6716 14 13.5C14 14.3284 13.1046 15 12 15M12 9C12.8708 9 13.6116 9.4174 13.8862 10M12 9V8M12 15C11.1292 15 10.3884 14.5826 10.1138 14M12 15V16"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" />
                                <path
                                    d="M21 11.1833V8.28029C21 6.64029 21 5.82028 20.5959 5.28529C20.1918 4.75029 19.2781 4.49056 17.4507 3.9711C16.2022 3.6162 15.1016 3.18863 14.2223 2.79829C13.0234 2.2661 12.424 2 12 2C11.576 2 10.9766 2.2661 9.77771 2.79829C8.89839 3.18863 7.79784 3.61619 6.54933 3.9711C4.72193 4.49056 3.80822 4.75029 3.40411 5.28529C3 5.82028 3 6.64029 3 8.28029V11.1833C3 16.8085 8.06277 20.1835 10.594 21.5194C11.2011 21.8398 11.5046 22 12 22C12.4954 22 12.7989 21.8398 13.406 21.5194C15.9372 20.1835 21 16.8085 21 11.1833Z"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" />
                            </svg>
                            <h5 className="card-title mt-3">Zero Deduction Gold Exchange</h5>
                        </div>
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path d="M22 14.0057C22 17.3206 19.3171 20.0017 16 20.0017L16.8571 18.2886"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M2 10.0086C2 6.69363 4.68286 4.01257 8 4.01257L7.14286 5.72571" stroke="currentColor"
                                    stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M10.9658 5.52406H21.7723M13.4658 10.9943H19.4999C20.8806 10.9943 21.9999 9.87573 21.9999 8.49595V4.49674C21.9999 3.11695 20.8806 1.99841 19.4999 1.99841H13.4658C12.0851 1.99841 10.9658 3.11695 10.9658 4.49674V8.49595C10.9658 9.87573 12.0851 10.9943 13.4658 10.9943Z"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M2 16.5314H12.8065M4.5 22.0016H10.5341C11.9148 22.0016 13.0341 20.8831 13.0341 19.5033V15.5041C13.0341 14.1243 11.9148 13.0057 10.5341 13.0057H4.5C3.11929 13.0057 2 14.1243 2 15.5041V19.5033C2 20.8831 3.11929 22.0016 4.5 22.0016Z"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <h5 className="card-title mt-3">Easy Exchange</h5>
                        </div>
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path
                                    d="M21.3175 7.14139L20.8239 6.28479C20.4506 5.63696 20.264 5.31305 19.9464 5.18388C19.6288 5.05472 19.2696 5.15664 18.5513 5.36048L17.3311 5.70418C16.8725 5.80994 16.3913 5.74994 15.9726 5.53479L15.6357 5.34042C15.2766 5.11043 15.0004 4.77133 14.8475 4.37274L14.5136 3.37536C14.294 2.71534 14.1842 2.38533 13.9228 2.19657C13.6615 2.00781 13.3143 2.00781 12.6199 2.00781H11.5051C10.8108 2.00781 10.4636 2.00781 10.2022 2.19657C9.94085 2.38533 9.83106 2.71534 9.61149 3.37536L9.27753 4.37274C9.12465 4.77133 8.84845 5.11043 8.48937 5.34042L8.15249 5.53479C7.73374 5.74994 7.25259 5.80994 6.79398 5.70418L5.57375 5.36048C4.85541 5.15664 4.49625 5.05472 4.17867 5.18388C3.86109 5.31305 3.67445 5.63696 3.30115 6.28479L2.80757 7.14139C2.45766 7.74864 2.2827 8.05227 2.31666 8.37549C2.35061 8.69871 2.58483 8.95918 3.05326 9.48012L4.0843 10.6328C4.3363 10.9518 4.51521 11.5078 4.51521 12.0077C4.51521 12.5078 4.33636 13.0636 4.08433 13.3827L3.05326 14.5354C2.58483 15.0564 2.35062 15.3168 2.31666 15.6401C2.2827 15.9633 2.45766 16.2669 2.80757 16.8741L3.30114 17.7307C3.67443 18.3785 3.86109 18.7025 4.17867 18.8316C4.49625 18.9608 4.85542 18.8589 5.57377 18.655L6.79394 18.3113C7.25263 18.2055 7.73387 18.2656 8.15267 18.4808L8.4895 18.6752C8.84851 18.9052 9.12464 19.2442 9.2775 19.6428L9.61149 20.6403C9.83106 21.3003 9.94085 21.6303 10.2022 21.8191C10.4636 22.0078 10.8108 22.0078 11.5051 22.0078H12.6199C13.3143 22.0078 13.6615 22.0078 13.9228 21.8191C14.1842 21.6303 14.294 21.3003 14.5136 20.6403L14.8476 19.6428C15.0004 19.2442 15.2765 18.9052 15.6356 18.6752L15.9724 18.4808C16.3912 18.2656 16.8724 18.2055 17.3311 18.3113L18.5513 18.655C19.2696 18.8589 19.6288 18.9608 19.9464 18.8316C20.264 18.7025 20.4506 18.3785 20.8239 17.7307L21.3175 16.8741C21.6674 16.2669 21.8423 15.9633 21.8084 15.6401C21.7744 15.3168 21.5402 15.0564 21.0718 14.5354L20.0407 13.3827C19.7887 13.0636 19.6098 12.5078 19.6098 12.0077C19.6098 11.5078 19.7888 10.9518 20.0407 10.6328L21.0718 9.48012C21.5402 8.95918 21.7744 8.69871 21.8084 8.37549C21.8423 8.05227 21.6674 7.74864 21.3175 7.14139Z"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" />
                                <path d="M12 8V12L14.8037 13.5" stroke="currentColor" stroke-width="0.7" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <h5 className="card-title mt-3">Asured Lifetime Maintenance</h5>
                        </div>
                        <div className="column">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="62" height="62" color="#000000"
                                fill="none">
                                <path d="M9 13C9 13 10 13 11 15C11 15 14.1765 10 17 9" stroke="currentColor" stroke-width="0.7"
                                    stroke-linecap="round" stroke-linejoin="round" />
                                <path
                                    d="M21 11.1833V8.28029C21 6.64029 21 5.82028 20.5959 5.28529C20.1918 4.75029 19.2781 4.49056 17.4507 3.9711C16.2022 3.6162 15.1016 3.18863 14.2223 2.79829C13.0234 2.2661 12.424 2 12 2C11.576 2 10.9766 2.2661 9.77771 2.79829C8.89839 3.18863 7.79784 3.61619 6.54933 3.9711C4.72193 4.49056 3.80822 4.75029 3.40411 5.28529C3 5.82028 3 6.64029 3 8.28029V11.1833C3 16.8085 8.06277 20.1835 10.594 21.5194C11.2011 21.8398 11.5046 22 12 22C12.4954 22 12.7989 21.8398 13.406 21.5194C15.9372 20.1835 21 16.8085 21 11.1833Z"
                                    stroke="currentColor" stroke-width="0.7" stroke-linecap="round" />
                            </svg>
                            <h5 className="card-title mt-3">Tested and Certified Diamond</h5>
                        </div>
                    </div>
                </div>
            </section>

            <section className="fluid-block collections pattern-2">
                <div className="container">
                    <div className="title-div d-flex align-items-center justify-content-between">
                        <div className="left">
                            <h2 className="text-uppercase fw-bold mb-0">Kanchipuram Silks</h2>
                            <ul className="d-flex align-items-center">
                                <li>Lorem Dolor</li>
                                <li><strong>10% Off collections</strong></li>
                            </ul>
                        </div>
                        <div className="right">
                            <Link href="#" className="btn btn-outline-primary text-uppercase">View All</Link>
                        </div>
                    </div>
                    <div className="owl-carousel" id="collections-2">
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/k-1.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/k-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/k-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/k-4.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/k-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/k-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="fluid-block collections pattern-3">
                <div className="container">
                    <div className="title-div d-flex align-items-center justify-content-between">
                        <div className="left">
                            <h2 className="text-uppercase fw-bold mb-0">heritage looms</h2>
                            <ul className="d-flex align-items-center">
                                <li>Lorem Dolor</li>
                                <li><strong>10% Off collections</strong></li>
                            </ul>
                        </div>
                        <div className="right">
                            <Link href="#" className="btn btn-outline-primary text-uppercase">View All</Link>
                        </div>
                    </div>
                    <div className="owl-carousel" id="collections-2">
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/h-1.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/h-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/h-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/h-4.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/h-2.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                        <div className="item">
                            <div className="card border-0 rounded-0">
                                <Link href="#" className="card-img">
                                    <img src="/assets/images/h-3.jpg" alt="" className="img-fluid" />
                                </Link>
                                <Link href="#"
                                    className="card-body d-flex align-items-center justify-content-between py-3 px-4 shadow-lg">
                                    <div className="left">
                                        Pure uppada partly silk saree
                                    </div>
                                    <div className="right">
                                        <i className="bi bi-arrow-right-short"></i>
                                    </div>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="fluid-block masonry pt-0">
                <div className="container">
                    <div className="row g-5">
                        <div className="col-lg-12">
                            <div className="video-box shadow-lg">
                                <video className="video" id="video-style" width="100%" poster="images/video_thumbnail.jpg">
                                    <source src="videos/home-hero-updated-voice.mp4" type="video/mp4" />
                                </video>
                                <div className="controls">
                                    <button className="play" onclick="playVideo()" style={{ zIndex: "1" }}><i
                                        className="bi bi-play-fill"></i></button>
                                    <button className="pause" onclick="pauseVideo()" style={{ display: "none", zIndex: "0" }}><i
                                        className="bi bi-pause"></i></button>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card border-0">
                                <div className="card-body position-relative p-0">
                                    <div className="card-title position-absolute p-5">
                                        <h2>Pure silk sarees</h2>
                                        <Link href="#" className="btn btn-outline-light rounded-0">View All Collections</Link>
                                    </div>
                                    <div className="card-img"><img src="/assets/images/m-1.jpg" alt="" /></div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3">
                            <div className="card border-0">
                                <div className="card-body position-relative p-0">
                                    <div className="card-title position-absolute p-5">
                                        <h2>cotton Silk sarees</h2>
                                        <Link href="#" className="btn btn-outline-light rounded-0 w-100">View All Collections</Link>
                                    </div>
                                    <div className="card-img"><img src="/assets/images/m-2.jpg" alt="" /></div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3">
                            <div className="card border-0">
                                <div className="card-body position-relative p-0">
                                    <div className="card-title position-absolute p-5">
                                        <h2>Gadwal Silk sarees</h2>
                                        <Link href="#" className="btn btn-outline-light rounded-0 w-100">View All Collections</Link>
                                    </div>
                                    <div className="card-img"><img src="/assets/images/m-3.jpg" alt="" /></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="fluid-block features-2 text-center py-5">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3 border-end">
                            <img src="/assets/images/free-shipping.png" alt="" />
                            <h4 className="mt-3">Free-Shipping</h4>
                            <small>All over India</small>
                        </div>
                        <div className="col-lg-3 border-end">
                            <img src="/assets/images/tailoring.png" alt="" />
                            <h4 className="mt-3">Custom tailoring</h4>
                            <small>Blouse Stitching as per size</small>
                        </div>
                        <div className="col-lg-3 border-end">
                            <img src="/assets/images/worldwide.png" alt="" />
                            <h4 className="mt-3">Worldwide shipping</h4>
                            <small>Get Delivery all over World</small>
                        </div>
                        <div className="col-lg-3">
                            <img src="/assets/images/support.png" alt="" />
                            <h4 className="mt-3">Online Customer Support</h4>
                            <small>Offering 24X7 Customer Support</small>
                        </div>
                    </div>
                </div>
            </section>

            <footer>
                <div className="footer-top">
                    <div className="container">
                        <div className="row g-5">
                            <div className="col-lg-3">
                                <div className="link-wrap">
                                    <h5>Useful links</h5>
                                    <ul>
                                        <li> <Link href="#">Delivery Information</Link></li>
                                        <li> <Link href="#">International Shipping</Link></li>
                                        <li> <Link href="#">Payment Options</Link></li>
                                        <li> <Link href="#">Track your Order</Link></li>
                                        <li> <Link href="#">Returns</Link></li>
                                        <li> <Link href="#">Find a Store</Link></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="link-wrap">
                                    <h5>Information</h5>
                                    <ul>
                                        <li> <Link href="#">Careers</Link></li>
                                        <li> <Link href="#">Blog</Link></li>
                                        <li> <Link href="#">Offers & Contest Details</Link></li>
                                        <li> <Link href="#">Help & FAQs</Link></li>
                                        <li> <Link href="#">About Sangama Silk</Link></li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="link-wrap">
                                    <h5>Contact Us</h5>
                                    <ul>
                                        <li className="d-flex align-items-center"><i className="bi bi-envelope"></i> <Link
                                            href="#">info@sangamasilks.com</Link></li>
                                        <li className="d-flex align-items-center"><i className="bi bi-telephone"></i> <Link
                                            href="#">9876543210</Link></li>
                                        <li className="d-flex align-items-center"><i className="bi bi-chat-right-text"></i> <Link
                                            href="#">Chat with Us</Link></li>
                                    </ul>
                                    <div className="input-group mb-3">
                                        <input type="text" className="form-control" placeholder="Enter your email"
                                            aria-label="Recipient's username" aria-describedby="button-addon2" />
                                        <button className="btn btn-primary px-4" type="button" id="button-addon2">Subscribe</button>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-3">
                                <div className="link-wrap">
                                    <h5>Follow Us On</h5>
                                    <ul>
                                        <li className="d-flex align-items-center"><i className="bi bi-facebook"></i> <Link
                                            href="#">Facebook</Link></li>
                                        <li className="d-flex align-items-center"><i className="bi bi-instagram"></i> <Link
                                            href="#">Instagram</Link></li>
                                        <li className="d-flex align-items-center"><i className="bi bi-youtube"></i> <Link
                                            href="#">Youtube</Link></li>
                                        <li className="d-flex align-items-center"><i className="bi bi-linkedin"></i> <Link
                                            href="#">Linkedin</Link></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="footer-bottom">
                    <div className="container">
                        <div className="d-flex justify-content-between align-items-center">
                            <div className="payments">
                                <ul className="d-flex">
                                    <li> <Link href="#">

                                    </Link></li>
                                    <li> <Link href="#">

                                    </Link></li>
                                    <li> <Link href="#">

                                    </Link></li>
                                </ul>
                            </div>
                            <div className="copyright">© 2025 Sangama Silk. All Rights Reserved</div>
                        </div>
                    </div>
                </div>
            </footer>
        </>
    );
};

export default FestivalCollections;
