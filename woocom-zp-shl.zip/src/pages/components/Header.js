import Link from 'next/link';

export default function Header() {
  return (
    <>
      {/* Header start */}
      <header>
        <div className="top-bar">
          <div className="container">
            <div className="d-flex align-items-center justify-content-between">
              <div className="left">
                <span>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="#000000" fill="none">
                    {/* SVG paths unchanged */}
                  </svg>
                  Support Center: <a href="#">+91 1234567890</a>
                </span>
              </div>
              <div className="right">
                <div className="btn-group" role="group" aria-label="Button group with nested dropdown">
                  <div className="btn-group" role="group">
                    <button type="button" className="btn dropdown-toggle text-white rounded-2" data-bs-toggle="dropdown" aria-expanded="false">
                      Appointment
                    </button>
                    <ul className="dropdown-menu">
                      <li><a className="dropdown-item" href="#">Dropdown link</a></li>
                      <li><a className="dropdown-item" href="#">Dropdown link</a></li>
                    </ul>
                  </div>
                  <div className="btn-group" role="group">
                    <button type="button" className="btn dropdown-toggle text-white rounded-2" data-bs-toggle="dropdown" aria-expanded="false">
                      English
                    </button>
                    <ul className="dropdown-menu">
                      <li><a className="dropdown-item" href="#">Dropdown link</a></li>
                      <li><a className="dropdown-item" href="#">Dropdown link</a></li>
                    </ul>
                  </div>
                  <div className="btn-group" role="group">
                    <button type="button" className="btn dropdown-toggle text-white rounded-2" data-bs-toggle="dropdown" aria-expanded="false">
                      INR
                    </button>
                    <ul className="dropdown-menu">
                      <li><a className="dropdown-item" href="#">Dropdown link</a></li>
                      <li><a className="dropdown-item" href="#">Dropdown link</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <nav className="navbar navbar-expand-lg" id="navbar_top">
          <div className="container">
            <a className="navbar-brand" href="#">
              <img src="images/logo.png" alt="HomeyBites" />
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarScroll"
              aria-controls="navbarScroll"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarScroll">
              <ul className="navbar-nav mx-auto">
                <li className="nav-item dropdown has-megamenu position-relative">
                  <a className="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                    New arrival
                  </a>
                  <div className="dropdown-menu megamenu border-0 rounded-4" role="menu">
                    <div className="row">
                      {['Silk Collections', 'Gadwal Collections', 'Banarasi Collections', 'Trend Collections'].map((collection, index) => (
                        <div className="col-lg-3" key={index}>
                          <h4 className="badge rounded-pill">{collection}</h4>
                          <ul>
                            {['Kanchipuram silk sarees', 'Banarasi silk sarees', 'Kanjeevaram silk sarees', 'Mysore silk sarees'].map((item, index) => (
                              <li className="nav-item" key={index}>
                                <a className="nav-link" href="#">
                                  {item}
                                </a>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                </li>

                {/* Modify this part to use Link for Trends */}
                {['Pure Handloom Silk', 'Kanjivaram', 'Banarsi'].map((link, index) => (
                  <li className="nav-item" key={index}>
                    <a className="nav-link" href="#">
                      {link}
                    </a>
                  </li>
                ))}
                <li className="nav-item">
                  <Link href="/trends" className="nav-link">
                    Trends
                  </Link>
                </li>
              </ul>
            </div>
            <div className="icon-menu">
              <ul className="d-flex align-items-center gap-3">
                <li>
                  <div className="input-group search">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="What you are looking for?"
                      aria-describedby="button-addon2"
                    />
                    <button
                      className="btn btn-outline-secondary d-flex align-items-center justify-content-center"
                      type="button"
                      id="button-addon2"
                    ></button>
                  </div>
                </li>
                <li>
                  <a href="#"> {/* Add Icon Here */} </a>
                </li>
                <li>
                  <a href="#"> {/* Add Icon Here */} </a>
                </li>
                <li>
                  <a href="#" className="position-relative">
                    <span className="badge position-absolute translate-middle badge rounded-pill bg-danger">
                      0
                    </span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      {/* Header End */}

      {/* banner slider start */}
      <section className="banner-section">
        <div className="owl-carousel owl-theme" id="banner_slider">
          <div className="item"> <Link href="#"><img src="/assets/images/slider-1.jpg" alt="Sangama Silk1" /></Link></div>
          <div className="item"> <Link href="#"><img src="/assets/images/slider-1.jpg" alt="Sangama Silk2" /></Link></div>
          <div className="item"> <Link href="#"><img src="/assets/images/slider-1.jpg" alt="Sangama Silk3" /></Link></div>
        </div>
      </section>
      {/* banner slider End */}
    </>
  );
}
