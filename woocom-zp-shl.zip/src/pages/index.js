import Header from "./components/Header";
import TopCollections from "./components/TopCollections";
import FestivalCollections from "./components/FestivalCollections";
export default function Home() {
    return (
        <>
            <Header />

            <TopCollections />

            <FestivalCollections />
            
        </>
    );
}
